<?php
/**
 * File for class RapidoServiceFan_curl_open
 * @package Rapido
 * @subpackage Services
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2018-03-09
 */
/**
 * This class stands for RapidoServiceFan_curl_open originally named Fan_curl_open
 * @package Rapido
 * @subpackage Services
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2018-03-09
 */
class RapidoServiceFan_curl_open extends RapidoWsdlClass
{
    /**
     * Method to call the operation originally named fan_curl_open
     * Documentation : fan_curl_open
     * @uses RapidoWsdlClass::getSoapClient()
     * @uses RapidoWsdlClass::setResult()
     * @uses RapidoWsdlClass::saveLastError()
     * @param anyType $_url
     * @param anyType $_data
     * @return void
     */
    public function fan_curl_open($_url,$_data)
    {
        try
        {
            return $this->setResult(self::getSoapClient()->fan_curl_open($_url,$_data));
        }
        catch(SoapFault $soapFault)
        {
            return !$this->saveLastError(__METHOD__,$soapFault);
        }
    }
    /**
     * Returns the result
     * @see RapidoWsdlClass::getResult()
     * @return void
     */
    public function getResult()
    {
        return parent::getResult();
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}

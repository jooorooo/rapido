<?php
/**
 * File for class RapidoServiceCheck_siteid
 * @package Rapido
 * @subpackage Services
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2018-03-09
 */
/**
 * This class stands for RapidoServiceCheck_siteid originally named Check_siteid
 * @package Rapido
 * @subpackage Services
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2018-03-09
 */
class RapidoServiceCheck_siteid extends RapidoWsdlClass
{
    /**
     * Method to call the operation originally named check_siteid
     * Documentation : Проверка за обмяна със ПОДИЗПЪЛНИТЕЛ.
     * @uses RapidoWsdlClass::getSoapClient()
     * @uses RapidoWsdlClass::setResult()
     * @uses RapidoWsdlClass::saveLastError()
     * @param UNKNOWN $_loginparam
     * @param string $_siteid
     * @return string
     */
    public function check_siteid($_loginparam,$_siteid)
    {
        try
        {
            return $this->setResult(self::getSoapClient()->check_siteid($_loginparam,$_siteid));
        }
        catch(SoapFault $soapFault)
        {
            return !$this->saveLastError(__METHOD__,$soapFault);
        }
    }
    /**
     * Returns the result
     * @see RapidoWsdlClass::getResult()
     * @return string
     */
    public function getResult()
    {
        return parent::getResult();
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}

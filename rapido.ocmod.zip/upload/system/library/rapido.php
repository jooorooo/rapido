<?php
class Rapido {
	private $error;

	private $url;
	private $loginParam;

	const SERVICE_CITY = 1;
	const SERVICE_INTERCITY = 2;

	const STREET_TYPE = 1;
	const QUARTER_TYPE = 2;

	const COUNTRIES = array(4 => 'AF', 248 => 'AX', 8 => 'AL', 12 => 'DZ', 16 => 'AS', 20 => 'AD', 24 => 'AO', 660 => 'AI', 10 => 'AQ', 28 => 'AG', 32 => 'AR', 51 => 'AM', 533 => 'AW', 36 => 'AU', 40 => 'AT', 31 => 'AZ', 44 => 'BS', 48 => 'BH', 50 => 'BD', 52 => 'BB', 112 => 'BY', 56 => 'BE', 84 => 'BZ', 204 => 'BJ', 60 => 'BM', 64 => 'BT', 68 => 'BO', 70 => 'BA', 72 => 'BW', 74 => 'BV', 76 => 'BR', 86 => 'IO', 96 => 'BN', 100 => 'BG', 854 => 'BF', 108 => 'BI', 116 => 'KH', 120 => 'CM', 124 => 'CA', 132 => 'CV', 136 => 'KY', 140 => 'CF', 148 => 'TD', 152 => 'CL', 156 => 'CN', 162 => 'CX', 166 => 'CC', 170 => 'CO', 174 => 'KM', 178 => 'CG', 180 => 'CD', 184 => 'CK', 188 => 'CR', 384 => 'CI', 191 => 'HR', 192 => 'CU', 531 => 'CW', 196 => 'CY', 203 => 'CZ', 208 => 'DK', 262 => 'DJ', 212 => 'DM', 214 => 'DO', 218 => 'EC', 818 => 'EG', 222 => 'SV', 226 => 'GQ', 232 => 'ER', 233 => 'EE', 231 => 'ET', 238 => 'FK', 234 => 'FO', 242 => 'FJ', 246 => 'FI', 250 => 'FR', 254 => 'GF', 258 => 'PF', 260 => 'TF', 266 => 'GA', 270 => 'GM', 268 => 'GE', 276 => 'DE', 288 => 'GH', 292 => 'GI', 300 => 'GR', 304 => 'GL', 308 => 'GD', 312 => 'GP', 316 => 'GU', 320 => 'GT', 831 => 'GG', 324 => 'GN', 624 => 'GW', 328 => 'GY', 332 => 'HT', 334 => 'HM', 336 => 'VA', 340 => 'HN', 344 => 'HK', 348 => 'HU', 352 => 'IS', 356 => 'IN', 360 => 'ID', 364 => 'IR', 368 => 'IQ', 372 => 'IE', 833 => 'IM', 376 => 'IL', 380 => 'IT', 388 => 'JM', 392 => 'JP', 832 => 'JE', 400 => 'JO', 398 => 'KZ', 404 => 'KE', 296 => 'KI', 408 => 'KP', 410 => 'KR', 414 => 'KW', 417 => 'KG', 418 => 'LA', 428 => 'LV', 422 => 'LB', 426 => 'LS', 430 => 'LR', 434 => 'LY', 438 => 'LI', 440 => 'LT', 442 => 'LU', 446 => 'MO', 807 => 'MK', 450 => 'MG', 454 => 'MW', 458 => 'MY', 462 => 'MV', 466 => 'ML', 470 => 'MT', 584 => 'MH', 474 => 'MQ', 478 => 'MR', 480 => 'MU', 175 => 'YT', 484 => 'MX', 583 => 'FM', 498 => 'MD', 492 => 'MC', 496 => 'MN', 499 => 'ME', 500 => 'MS', 504 => 'MA', 508 => 'MZ', 104 => 'MM', 516 => 'NA', 520 => 'NR', 524 => 'NP', 528 => 'NL', 540 => 'NC', 554 => 'NZ', 558 => 'NI', 562 => 'NE', 566 => 'NG', 570 => 'NU', 574 => 'NF', 580 => 'MP', 578 => 'NO', 512 => 'OM', 586 => 'PK', 585 => 'PW', 591 => 'PA', 598 => 'PG', 600 => 'PY', 604 => 'PE', 608 => 'PH', 612 => 'PN', 616 => 'PL', 620 => 'PT', 630 => 'PR', 634 => 'QA', 638 => 'RE', 642 => 'RO', 643 => 'RU', 646 => 'RW', 652 => 'BL', 659 => 'KN', 662 => 'LC', 663 => 'MF', 666 => 'PM', 670 => 'VC', 882 => 'WS', 674 => 'SM', 678 => 'ST', 682 => 'SA', 686 => 'SN', 688 => 'RS', 690 => 'SC', 694 => 'SL', 702 => 'SG', 534 => 'SX', 703 => 'SK', 705 => 'SI', 90 => 'SB', 706 => 'SO', 710 => 'ZA', 239 => 'GS', 728 => 'SS', 724 => 'ES', 144 => 'LK', 729 => 'SD', 740 => 'SR', 744 => 'SJ', 748 => 'SZ', 752 => 'SE', 756 => 'CH', 760 => 'SY', 762 => 'TJ', 764 => 'TH', 626 => 'TL', 768 => 'TG', 772 => 'TK', 776 => 'TO', 780 => 'TT', 788 => 'TN', 792 => 'TR', 795 => 'TM', 796 => 'TC', 798 => 'TV', 800 => 'UG', 804 => 'UA', 784 => 'AE', 826 => 'GB', 840 => 'US', 581 => 'UM', 858 => 'UY', 860 => 'UZ', 548 => 'VU', 862 => 'VE', 704 => 'VN', 92 => 'VG', 850 => 'VI', 876 => 'WF', 732 => 'EH', 887 => 'YE', 894 => 'ZM', 716 => 'ZW');
	const BULGARIA = 100;

	const PAYER_SENDER = 0;
	const PAYER_RECEIVER = 1;

	const PRICE_LIST_PAYER = 0;
	const PRICE_LIST_SENDER = 1;
	const PRICE_LIST_RECEIVER = 2;

	const PRINT_FORMAT_A4 = 1;
	const PRINT_FORMAT_LABEL = 2;

	const STATUS_OFFICE = 3;

	const MEDIATOR = 'extensa';
	const PLATFORM = 'opencart1';
	const MODULE_VERSION = '2.3.5';

	public function __construct($registry) {
		$this->config = $registry->get('config');
		$this->request = $registry->get('request');
		$this->log = $registry->get('log');

		if (isset($this->request->post['rapido_test'])) {
			$test = $this->request->post['rapido_test'];
		} else {
			$test = $this->config->get('rapido_test');
		}

		if (!$test) {
			$this->url = 'https://www.rapido.bg/rsystem2/schema.wsdl';
		} else {
			$this->url = 'https://www.rapido.bg/testsystem/schema.wsdl';
		}

		if (isset($this->request->post['rapido_username'])) {
			$username = $this->request->post['rapido_username'];
		} else {
			$username = $this->config->get('rapido_username');
		}

		if (isset($this->request->post['rapido_password'])) {
			$password = $this->request->post['rapido_password'];
		} else {
			$password = $this->config->get('rapido_password');
		}

		$this->loginParam = new stdClass();
		$this->loginParam->user = $username;
		$this->loginParam->pass = $password;
	}

	public function getMyObjects() {
		$this->error = '';
		$objects = array();

		try {
			$client = new SoapClient($this->url);
			$results = $client->getMyObjects($this->loginParam);
			$default = 1;

			foreach ($results as $result) {
				$objects[$result['SOAP_OFFICE_ID']] = $result;
				$objects[$result['SOAP_OFFICE_ID']]['default'] = $default;
				$default = 0;
			}
		} catch (Exception $e) {
			$this->error = $e->getMessage();
			$this->log->write('Rapido :: getMyObjects :: ' . $e->getMessage());
		}

		return $objects;
	}

	public function getRazhodOrders($from_date = '', $to_date = '') {
		$this->error = '';
		$orders = array();

		try {
			$client = new SoapClient($this->url);
			$results = $client->getRazhodOrders($this->loginParam, $from_date, $to_date);

			foreach ($results as $result) {
				$orders[] =  array(
					'rid'      => $result['RID'],
					'created'  => $result['CREATED'],
					'tsum'     => $result['TSUM']
				);
			}
		} catch (Exception $e) {
			$this->error = $e->getMessage();
			$this->log->write('Rapido :: getRazhodOrders :: ' . $e->getMessage());
		}

		return $orders;
	}

	public function getSubServices($service) {
		$this->error = '';
		$subservices = array();

		try {
			$client = new SoapClient($this->url);
			$results = $client->getSubServices($this->loginParam, $service);

			foreach ($results as $result) {
				$subservices[$result['DATA']] = $result['LABEL'];
			}
		} catch (Exception $e) {
			$this->error = $e->getMessage();
			$this->log->write('Rapido :: getSubServices :: ' . $e->getMessage());
		}

		return $subservices;
	}

	public function getOfficesCity($city_id) {
		$this->error = '';
		$offices = array();

		try {
			$client = new SoapClient($this->url);
			$results = $client->getOfficesCity($this->loginParam, $city_id);

			foreach ($results as $result) {
				$offices[] = array(
					'id'    => $result['DATA'],
					'label' => $result['LABEL']
				);
			}
		} catch (Exception $e) {
			$this->error = $e->getMessage();
			$this->log->write('Rapido :: getOfficesCity :: ' . $e->getMessage());
		}

		return $offices;
	}

	public function getCountries($start = 0, $count = 1000) {
		$this->error = '';
		$countries = array();

		try {
			$client = new SoapClient($this->url);
			$countries = $client->getCountries($this->loginParam, $start, $count);
		} catch (Exception $e) {
			$this->error = $e->getMessage();
			$this->log->write('Rapido :: getCountries :: ' . $e->getMessage());
		}

		return $countries;
	}

	public function getCityes($country = 100, $start = 0, $count = 1000) {
		$this->error = '';
		$cities = array();

		try {
			$client = new SoapClient($this->url);
			$cities = $client->getCityes($this->loginParam, $country, $start, $count);
		} catch (Exception $e) {
			$this->error = $e->getMessage();
			$this->log->write('Rapido :: getCityes :: ' . $e->getMessage());
		}

		return $cities;
	}

	public function getStreets($siteid = 0, $start = 0, $count = 1000) {
		$this->error = '';
		$streets = array();

		try {
			$client = new SoapClient($this->url);
			$streets = $client->getStreets($this->loginParam, $siteid, $start, $count);
		} catch (Exception $e) {
			$this->error = $e->getMessage();
			$this->log->write('Rapido :: getStreets :: ' . $e->getMessage());
		}

		return $streets;
	}

	public function calculate($data) {
		$this->error = '';
		$prices = array();
		$params = array();

		$sender_city_id = (isset($data['sender_city_id']) ? $data['sender_city_id'] : $this->config->get('rapido_sender_city_id'));

		if ($data['city_id'] == $sender_city_id) {
			$params['service'] = self::SERVICE_CITY;
			$subservices = array_intersect_key($this->getSubServices($params['service']), array_flip($this->config->get('rapido_subservices_city')));
		} else {
			$params['service'] = self::SERVICE_INTERCITY;
			$subservices = array_intersect_key($this->getSubServices($params['service']), array_flip($this->config->get('rapido_subservices_intercity')));
		}

		$params['fix_chas'] = (isset($data['fixed_time_cb']) ? 1 : 0);
		$params['return_receipt'] = $this->config->get('rapido_return_receipt');
		$params['return_doc'] = $this->config->get('rapido_return_doc');
		$params['nal_platej'] = ($data['cod'] ? $data['total'] : 0);
		$insurance = (isset($data['insurance']) ? $data['insurance'] : $this->config->get('rapido_insurance'));
		$params['zastrahovka'] = ($insurance ? $data['insurance_total'] : 0);
		$params['teglo'] = $data['weight'];

		if ((float)$this->config->get('rapido_free_total') && ($data['total'] >= (float)$this->config->get('rapido_free_total'))) {
			$params['ZASMETKA'] = self::PAYER_SENDER;
		} elseif ((float)$this->config->get('rapido_fixed_total_city') && $params['service'] == self::SERVICE_CITY) {
			$params['ZASMETKA'] = self::PAYER_SENDER;
		} elseif ((float)$this->config->get('rapido_fixed_total_intercity') && $params['service'] == self::SERVICE_INTERCITY) {
			$params['ZASMETKA'] = self::PAYER_SENDER;
		} else {
			$params['ZASMETKA'] = $this->config->get('rapido_payer');
		}

		$params['CENOVA_LISTA'] = $this->config->get('rapido_price_list');

		try {
			$client = new SoapClient($this->url);

			foreach ($subservices as $subservice_data => $subservice_label) {
				$params['subservice'] = $subservice_data;
				$result = $client->calculate($this->loginParam, $params);

				$prices[$subservice_data] = $result;
				$prices[$subservice_data]['label'] = $subservice_label;
				$prices[$subservice_data]['service'] = $params['service'];
			}
		} catch (Exception $e) {
			$this->error = $e->getMessage();
			$this->log->write('Rapido :: calculate :: ' . $e->getMessage());
		}

		return $prices;
	}

	public function create_order($data, $order) {
		$this->error = '';
		$result = array();

		$params = array();
		$params['service'] = $data['service'];
		$params['subservice'] = $data['shipping_method_id'];
		$params['nal_platej'] = ($data['cod'] ? $data['total'] : 0);
		$insurance = (isset($data['insurance']) ? $data['insurance'] : $this->config->get('rapido_insurance'));
		$params['zastrahovka'] = ($insurance ? $data['insurance_total'] : 0);
		$params['CONTENT'] = $data['content'];
		$params['CHUPLIVO'] = $data['fragile'];
		$params['teglo'] = $data['weight'];
		$params['RECEIVER'] = $order['firstname'] . ' ' . $order['lastname'];
		$params['COUNTRY_B'] = $data['country_id'];
		$params['CITY_B'] = $data['city'];
		$params['SITEID_B'] = $data['city_id'];
		$params['PK_B'] = $data['postcode'];
		$params['SUBOTEN_RAZNOS'] = (int)$data['suboten_raznos'];
		$params['CHECK_BEFORE_PAY'] = (int)$data['check_before_pay'];
		$params['TEST_BEFORE_PAY'] = (int)$data['test_before_pay'];

		if (!$data['take_office']) {
			$params['STREET_B'] = ($data['street'] ? $data['street'] : $data['quarter']);
			$params['STREETB_ID'] = ($data['street_id'] ? $data['street_id'] : $data['quarter_id']);
			$params['STREETB_TYPE'] = ($data['street_id'] ? self::STREET_TYPE : self::QUARTER_TYPE);
			$params['STREET_NO_B'] = $data['street_no'];
			$params['BLOCK_B'] = $data['block_no'];
			$params['ENTRANCE_B'] = $data['entrance_no'];
			$params['FLOOR_B'] = $data['floor_no'];
			$params['APARTMENT_B'] = $data['apartment_no'];
			$params['ADDITIONAL_INFO_B'] = $data['additional_info'];
		} else {
			$params['TAKEOFFICE'] = $data['office_id'];
		}

		if (isset($data['send_email'])) {
			$params['EMAIL_B'] = $order['email'];
		}
		$params['PHONE_B'] = $order['telephone'];
		$params['fix_chas'] = (isset($data['fixed_time_cb']) ? self::getFixedTimeType($data['fixed_time_type']) . ':' . $data['fixed_time_hour'] . ':' . $data['fixed_time_min'] : '');
		$params['return_receipt'] = $this->config->get('rapido_return_receipt');
		$params['return_doc'] = $this->config->get('rapido_return_doc');
		$params['PACK_COUNT'] = $data['count'];
		$params['CLIENT_REF1'] = $order['order_id'];
		if (isset($data['pazar']) && !empty($data['pazar'])) {
			$params['PAZAR'] = (float)$data['pazar'];
		}

		if ((float)$this->config->get('rapido_free_total') && ($data['total'] >= (float)$this->config->get('rapido_free_total'))) {
			$params['ZASMETKA'] = self::PAYER_SENDER;
		} elseif ((float)$this->config->get('rapido_fixed_total_city') && $params['service'] == self::SERVICE_CITY) {
			$params['ZASMETKA'] = self::PAYER_SENDER;
			if ($params['nal_platej']) {
				$params['nal_platej'] += (float)$this->config->get('rapido_fixed_total_city');
			}
		} elseif ((float)$this->config->get('rapido_fixed_total_intercity') && $params['service'] == self::SERVICE_INTERCITY) {
			$params['ZASMETKA'] = self::PAYER_SENDER;
			if ($params['nal_platej']) {
				$params['nal_platej'] += (float)$this->config->get('rapido_fixed_total_intercity');
			}
		} else {
			$params['ZASMETKA'] = isset($data['payer']) ? $data['payer'] : $this->config->get('rapido_payer');
		}

		$params['CENOVA_LISTA'] = $this->config->get('rapido_price_list');

		$params['POST_MONEY_TRANSFER'] = (int)$this->config->get('rapido_money_transfer');

		if ($data['sender_office_id'] && !$data['sender_office_default']) {
			$params['SENDOFFICE'] = $data['sender_office_id'];
			$params['SENDHOUR'] = $data['sendhour'];
			$params['SENDMIN'] = $data['sendmin'];
			$params['WORKHOUR'] = $data['workhour'];
			$params['WORKMIN'] = $data['workmin'];
		}

		$params['mediator'] = self::MEDIATOR;
		$params['platform'] = self::PLATFORM;
		$params['platform_version'] = VERSION;
		$params['module_version'] = self::MODULE_VERSION;

		try {
			$client = new SoapClient($this->url);
			$result = $client->create_order($this->loginParam, $params);
		} catch (Exception $e) {
			$this->error = $e->getMessage();
			$this->log->write('Rapido :: create_order :: ' . $e->getMessage());
		}

		return $result;
	}

	public function track_order($tovaritelnica) {
		$this->error = '';
		$tracks = array();

		try {
			$client = new SoapClient($this->url);
			$tracks = $client->track_order($this->loginParam, $tovaritelnica);
		} catch (Exception $e) {
			$this->error = $e->getMessage();
			$this->log->write('Rapido :: track_order :: ' . $e->getMessage());
		}

		return $tracks;
	}

	public function getTovarInfo($tovaritelnica) {
		$this->error = '';
		$info = array();

		try {
			$client = new SoapClient($this->url);
			$results = $client->getTovarInfo($this->loginParam, $tovaritelnica);

			if (isset($results['TOVARITELNICA'])) {
				$info = $results;
			} else if (isset($results[0])) {
				$info = $results[0];
			}
		} catch (Exception $e) {
			$this->error = $e->getMessage();
			$this->log->write('Rapido :: getTovarInfo :: ' . $e->getMessage());
		}

		return $info;
	}

	public function getNPInfo($tovaritelnica) {
		$this->error = '';
		$info = array();

		try {
			$client = new SoapClient($this->url);
			$info = $client->getNPInfo($this->loginParam, $tovaritelnica);
		} catch (Exception $e) {
			$this->error = $e->getMessage();
			$this->log->write('Rapido :: getNPInfo :: ' . $e->getMessage());
		}

		return $info;
	}

	public function setPrintSettings() {
		$this->error = '';
		$result = '';

		if (isset($this->request->post['rapido_auto_print'])) {
			$auto_print = $this->request->post['rapido_auto_print'];
		} else {
			$auto_print = $this->config->get('rapido_auto_print');
		}

		if (isset($this->request->post['rapido_label_printer'])) {
			$label_printer = $this->request->post['rapido_label_printer'];
		} else {
			$label_printer = $this->config->get('rapido_label_printer');
		}

		if (isset($this->request->post['rapido_printer'])) {
			$printer = $this->request->post['rapido_printer'];
		} else {
			$printer = $this->config->get('rapido_printer');
		}

		$settings = array(
			'auto'    => (int)$auto_print,
			'format'  => ($label_printer ? self::PRINT_FORMAT_LABEL : self::PRINT_FORMAT_A4),
			'printer' => $printer
		);

		try {
			$client = new SoapClient($this->url);
			$result = $client->setPrintSettings($this->loginParam, $settings);
		} catch (Exception $e) {
			$this->error = $e->getMessage();
			$this->log->write('Rapido :: setPrintSettings :: ' . $e->getMessage());
		}

		return $result;
	}

	public function print_pdf($tovaritelnica, $label_printer = 0) {
		$this->error = '';
		$pdf = array();

		$format = ($label_printer ? self::PRINT_FORMAT_LABEL : self::PRINT_FORMAT_A4);

		try {
			$client = new SoapClient($this->url);
			$pdf = base64_decode($client->print_pdf($this->loginParam, $tovaritelnica, $format));
		} catch (Exception $e) {
			$this->error = $e->getMessage();
			$this->log->write('Rapido :: print_pdf :: ' . $e->getMessage());
		}

		return $pdf;
	}

	public function requestCurier($count, $weight, $sendoffice = 0, $readiness = '') {
		$this->error = '';
		$result = array();

		if (!$readiness) {
			$readiness = $this->config->get('rapido_readiness');
		}

		if (!$sendoffice) {
			$sendoffice = $this->config->get('rapido_sender_office_id');
		}

		try {
			$client = new SoapClient($this->url);
			$result = $client->requestCurier($this->loginParam, $count, $weight, $readiness, $sendoffice);
		} catch (Exception $e) {
			$this->error = $e->getMessage();
			$this->log->write('Rapido :: requestCurier :: ' . $e->getMessage());
		}

		return $result;
	}

	public function getRazhodOrderInfo($number) {
		$this->error = '';
		$result = array();

		try {
			$client = new SoapClient($this->url);
			$result = $client->getRazhodOrderInfo($this->loginParam, $number);
		} catch (Exception $e) {
			$this->error = $e->getMessage();
			$this->log->write('Rapido :: getRazhodOrderInfo :: ' . $e->getMessage());
		}

		return $result;
	}

	public function checkCityFixChas($city_id) {
		$this->error = '';
		$check = false;

		try {
			$client = new SoapClient($this->url);
			$check = $client->checkCityFixChas($this->loginParam, $city_id);
		} catch (Exception $e) {
			$this->error = $e->getMessage();
			$this->log->write('Rapido :: checkCityFixChas :: ' . $e->getMessage());
		}

		return $check;
	}

	public function getInvoiceType() {
		$this->error = '';
		$type = 0;

		try {
			$client = new SoapClient($this->url);
			$type = $client->getInvoiceType($this->loginParam);
		} catch (Exception $e) {
			$this->error = $e->getMessage();
			$this->log->write('Rapido :: getInvoiceType :: ' . $e->getMessage());
		}

		return $type;
	}

	public function getInvoices($from_date = '', $to_date = '') {
		$this->error = '';
		$invoices = array();

		try {
			$client = new SoapClient($this->url);
			$results = $client->getInvoices($this->loginParam, $from_date, $to_date);

			foreach ($results as $result) {
				$invoices[] =  array(
					'invoiceid' => $result['INVOICEID'],
					'created'   => $result['CREATED'],
					'paytype'   => $result['PAYTYPE'],
					'tcount'    => $result['TCOUNT'],
					'tsum'      => $result['TSUM'],
					'dds'       => $result['DDS'],
					'total'     => $result['TOTAL'],
				);
			}
		} catch (Exception $e) {
			$this->error = $e->getMessage();
			$this->log->write('Rapido :: getInvoices :: ' . $e->getMessage());
		}

		return $invoices;
	}

	public function getError() {
		return $this->error;
	}

	static function transliterate($value, $language_from = 'en', $language_to = 'bg') {
		$en = array('sht', 'zh', 'ts', 'tz', 'tc', 'c', 'ch', 'sh', 'yu', 'ya', 'yo', 'a', 'b', 'v', 'g', 'd', 'e', 'z', 'i', 'y', 'k', 'l', 'm', 'n', 'o', 'p', 'r', 's', 't', 'u', 'f', 'h', 'a', 'y', 'y', 'e', 'Zh', 'Sht', 'Ts', 'Tz', 'Tc', 'C', 'Ch', 'Sh', 'Yu', 'Ya', 'Yo', 'A', 'B', 'V', 'G', 'D', 'E', 'Z', 'I', 'Y', 'K', 'L', 'M', 'N', 'O', 'P', 'R', 'S', 'T', 'U', 'F', 'H', 'A', 'Y', 'Y', 'E', 'q', 'Q');
		$bg = array('щ', 'ж', 'ц', 'ц', 'ц', 'ц', 'ч', 'ш', 'ю', 'я', 'ё', 'а', 'б', 'в', 'г', 'д', 'е', 'з', 'и', 'й', 'к', 'л', 'м', 'н', 'о', 'п', 'р', 'с', 'т', 'у', 'ф', 'х', 'ъ', 'ь', 'ы', 'э', 'Ж', 'Щ', 'Ц', 'Ц', 'Ц', 'Ц', 'Ч', 'Ш', 'Ю', 'Я', 'Ё', 'А', 'Б', 'В', 'Г', 'Д', 'Е', 'З', 'И', 'Й', 'К', 'Л', 'М', 'Н', 'О', 'П', 'Р', 'С', 'Т', 'У', 'Ф', 'Х', 'Ъ', 'Ь', 'Ы', 'Э', 'я', 'Я');

		if ($language_from != $language_to) {
			$value = str_replace(${$language_from}, ${$language_to}, $value);
		}

		return $value;
	}

	static function getFixedTimeType($type) {
		$fixed_time_types = array(
			'before' => 'ПРЕДИ',
			'in'     => 'ТОЧНО',
			'after'  => 'СЛЕД'
		);

		if (isset($fixed_time_types[$type])) {
			return $fixed_time_types[$type];
		} else {
			return '';
		}
	}

	static function getCountryIdByIso($countryid_iso) {
		return self::COUNTRIES[$countryid_iso];
	}

	static function getVolumeWeight($width, $length, $height) {
		return round((((float)$width * (float)$length * (float)$height) / 6000), 3);
	}
}
?>
<?php
// Heading
$_['heading_title']      = 'Рапидо наложен платеж';

// Text
$_['text_payment']       = 'Плащане';
$_['text_success']       = 'Готово, промените са запазени!';
$_['text_rapido_cod']    = '<a onclick="window.open(\'http://www.rapido.bg/\');"><img src="view/image/payment/rapido.png" alt="Рапидо" title="Рапидо" style="border: 1px solid #EEEEEE;" /></a>';
$_['text_edit']          = 'Редактиране на Рапидо наложен платеж';

// Entry
$_['entry_order_status'] = 'Статус на поръчката:';
$_['entry_geo_zone']     = 'Гео-зона:';
$_['entry_status']       = 'Статус:';
$_['entry_sort_order']   = 'Поредност:';

// Error
$_['error_permission']   = 'Внимание: Нямате права за промяна в секцията!';
?>
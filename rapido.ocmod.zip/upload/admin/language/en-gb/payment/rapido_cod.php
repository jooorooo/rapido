<?php
// Heading
$_['heading_title']      = 'Rapido Cash On Delivery';

// Text
$_['text_payment']       = 'Payment';
$_['text_success']       = 'Success: You have modified Rapido Cash On Delivery payment module!';
$_['text_rapido_cod']    = '<a onclick="window.open(\'http://www.rapido.bg/\');"><img src="view/image/payment/rapido.png" alt="Rapido" title="Rapido" style="border: 1px solid #EEEEEE;" /></a>';
$_['text_edit']          = 'Edit Rapido Cash On Delivery';

// Entry
$_['entry_order_status'] = 'Order Status:';
$_['entry_geo_zone']     = 'Geo Zone:';
$_['entry_status']       = 'Status:';
$_['entry_sort_order']   = 'Sort Order:';

// Error
$_['error_permission']   = 'Warning: You do not have permission to modify payment Rapido Cash On Delivery!';
?>
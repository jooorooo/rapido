<?php
// Text
$_['text_title'] = 'Рапидо наложен платеж';
?>
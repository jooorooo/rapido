<?php
// Text
$_['text_title'] = 'Rapido Cash On Delivery';
?>